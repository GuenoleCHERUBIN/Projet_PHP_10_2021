USE `database`;


CREATE TABLE user(
    `ID` INT(11) NULL DEFAULT NULL,
    `name` VARCHAR(100) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
    `surname` VARCHAR(60) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
    `address` VARCHAR(60) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
    `zip` VARCHAR(6) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
    `ville` VARCHAR(60) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
    `pays` VARCHAR(60) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
    `email` VARBINARY(100) NULL DEFAULT NULL,
    `date_naissance` DATE NULL DEFAULT NULL,
    `admin` TINYINT(1) NOT NULL DEFAULT 0,
    `username` VARCHAR(100) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
    `password` VARCHAR(100) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE animal;
CREATE TABLE animal(
     `ID` INT(11) NULL DEFAULT NULL,
     `name` VARCHAR(100) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
     `race` VARCHAR(60) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
     `type_animal` VARCHAR(60) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
     `date_naissance` DATE NULL DEFAULT NULL,
     `date_prise_en_charge` DATE NULL DEFAULT NULL,
     `available` TINYINT(1) NOT NULL DEFAULT 1,
     `reserved` TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE reserved_animal;
CREATE TABLE IF NOT EXISTS `reserved_animal`(
    `ID` INT(11) NULL DEFAULT NULL,
    `ID_animal` INT(11) NULL DEFAULT NULL,
    `ID_user` INT(11) NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;