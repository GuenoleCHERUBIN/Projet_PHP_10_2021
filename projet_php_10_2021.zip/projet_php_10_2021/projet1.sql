-- --------------------------------------------------------
-- Hôte:                         127.0.0.1
-- Version du serveur:           10.6.4-MariaDB-1:10.6.4+maria~focal - mariadb.org binary distribution
-- SE du serveur:                debian-linux-gnu
-- HeidiSQL Version:             11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Listage de la structure de la table database. animal
DROP TABLE IF EXISTS `animal`;
CREATE TABLE IF NOT EXISTS `animal` (
  `ID` int(11) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `race` varchar(60) DEFAULT NULL,
  `type_animal` varchar(60) DEFAULT NULL,
  `date_naissance` date DEFAULT NULL,
  `date_prise_en_charge` date DEFAULT NULL,
  `available` tinyint(1) NOT NULL DEFAULT 1,
  `reserved` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Listage des données de la table database.animal : ~0 rows (environ)
DELETE FROM `animal`;
/*!40000 ALTER TABLE `animal` DISABLE KEYS */;
/*!40000 ALTER TABLE `animal` ENABLE KEYS */;

-- Listage de la structure de la table database. reserved_animal
DROP TABLE IF EXISTS `reserved_animal`;
CREATE TABLE IF NOT EXISTS `reserved_animal` (
  `ID` int(11) DEFAULT NULL,
  `ID_animal` int(11) DEFAULT NULL,
  `ID_user` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Listage des données de la table database.reserved_animal : ~0 rows (environ)
DELETE FROM `reserved_animal`;
/*!40000 ALTER TABLE `reserved_animal` DISABLE KEYS */;
/*!40000 ALTER TABLE `reserved_animal` ENABLE KEYS */;

-- Listage de la structure de la table database. user
DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `ID` int(11) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `surname` varchar(60) DEFAULT NULL,
  `address` varchar(60) DEFAULT NULL,
  `zip` varchar(6) DEFAULT NULL,
  `ville` varchar(60) DEFAULT NULL,
  `pays` varchar(60) DEFAULT NULL,
  `email` varbinary(100) DEFAULT NULL,
  `date_naissance` date DEFAULT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT 0,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Listage des données de la table database.user : ~1 rows (environ)
DELETE FROM `user`;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`ID`, `name`, `surname`, `address`, `zip`, `ville`, `pays`, `email`, `date_naissance`, `admin`, `username`, `password`) VALUES
	(0, 'ADMIN', 'admin', 'admin address', '92456', 'admintown', 'admin', _binary 0x61646d696e406d61696c2e636f6d, '2021-10-12', 1, 'Admin', 'passadmin');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
