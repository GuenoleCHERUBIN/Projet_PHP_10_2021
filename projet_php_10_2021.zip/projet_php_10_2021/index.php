<?php

session_start();

require_once('Controller/User.php');

try {
    echo 'Current PHP version: ' . phpversion();
    echo '<br />';
    $_SESSION["User"] = new User();

    $_SESSION["User"]->getUser('Admin','passadmin');

    echo $_SESSION["User"]->getName();
    print_r($_SESSION);




    echo '<br />';
} catch (\Throwable $t) {
    echo 'Error: ' . $t->getMessage();
    echo '<br />';
}
?>

<html lang="EN">
    <a href="Views/animaux.php">Tous nos animaux</a>
</html>