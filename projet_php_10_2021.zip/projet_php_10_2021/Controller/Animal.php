<?php
require_once('Connect.php');

class Animal extends Connect
{
    /**
     * ID(type="integer")
     */
    public $id;

    /**
     * name(type="string", length=100)
     */
    public $name;

    /**
     * race(type="string", length=60)
     */
    public $race;

    /**
     * type_animal(type="string", length=60)
     */
    public $type_animal;

    /**
     * date_naissance(type="date")
     */
    public $date_naissance;
    /**
     * date_prise_en_charge(type="date")
     */
    public $date_prise_en_charge;

    /**
     * available(type="boolean")
     */
    public $available;
    /**
     * reserved(type="boolean")
     */
    public $reserved;

    public function __construct()
    {
    }

    function getAnimal($id)
    {
        $sql = 'SELECT * FROM animal WHERE ID = "' . $id . '"';
        $connexion = new Connect();
        $sth = $connexion->connexion()->prepare($sql);
        $sth->execute();
        $result = $sth->fetch();
        $this->id = $result["ID"];
        $this->name = $result["name"];
        $this->race = $result["race"];
        $this->type_animal = $result["type_animal"];
        $this->date_naissance = $result["date_naissance"];
        $this->date_prise_en_charge = $result["date_prise_en_charge"];
        $this->available = $result["available"];
        $this->reserved = $result["reserved"];


    }

    public function getID()
    {
        return $this->id;
    }

    public function getName()
    {
        return $this->name;
    }

    public function getRace()
    {
        return $this->race;
    }

    public function getType()
    {
        return $this->type_animal;
    }
    public function getBirth()
    {
        return $this->date_naissance;
    }
    public function getTakenIn()
    {
        return $this->date_prise_en_charge;
    }
    public function isAvailable()
    {
        return $this->available;
    }
    public function isReserved()
    {
        return $this->reserved;
    }
}
