<?php
require_once('Animal.php');

class Animals extends Animal
{


    function getLastAnimals()
    {
        $sql = 'SELECT * FROM animal ORDER BY ID DESC';
        $connexion = new Connect();
        $sth = $connexion->connexion()->prepare($sql);
        $sth->execute();
        $results = $sth->fetchAll();
        $animals = [];
        $i = 0;
        foreach($results as $result) {
            $animals[$i]["id"] = $result["ID"];
            $i++;
        }

        return $animals;
    }
}