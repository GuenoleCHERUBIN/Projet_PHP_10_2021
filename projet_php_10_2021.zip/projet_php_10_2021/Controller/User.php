<?php
require_once('Connect.php');

    class User extends Connect {
        /**
         * ID(type="integer")
         */
        private $id;

        /**
         * name(type="string", length=100)
         */
        private $name;

        /**
         * surname(type="string", length=60)
         */
        private $surname;

        /**
         * address(type="string", length=60)
         */
        private $address;

        /**
         * zip(type="string", length=6)
         */
        private $zip;

        /**
         * ville(type="string", length=60)
         */
        private $ville;

        /**
         * pays(type="string", length=60)
         */
        private $pays;

        /**
         * email(type="mail", length=100)
         */
        private $email;

        /**
         * date_naissance(type="date")
         */
        private $date_naissance;

        /**
         * admin(type="boolean")
         */
        private $admin;

        public function __construct(
        ){}

        function getUsers() {
            $sql = 'SELECT * FROM user';
            $connexion = new Connect();
            $sth = $connexion->connexion()->prepare($sql);
            $sth->execute();
            return $result = $sth->fetchAll();;
        }

        function getUser($username, $pass) {
            $sql = 'SELECT * FROM user WHERE username = "'. $username .'" AND password = "'. $pass .'"' ;
            $connexion = new Connect();
            $sth = $connexion->connexion()->prepare($sql);
            $sth->execute();
            $result = $sth->fetch();
            $this->id = $result["ID"];
            $this->name = $result["name"];
            $this->surname = $result["surname"];
            $this->address = $result["address"];
            $this->zip  = $result["zip"];
            $this->ville = $result["ville"];
            $this->pays  = $result["pays"];
            $this->email  = $result["email"];
            $this->date_naissance  = $result["date_naissance"];
            $this->admin  = $result["admin"];
        }

        public function getID()
        {
            return $this->id;
        }

        public function getName()
        {
            return $this->name;
        }

        public function getSurname()
        {
            return $this->surname;
        }
    }
?>