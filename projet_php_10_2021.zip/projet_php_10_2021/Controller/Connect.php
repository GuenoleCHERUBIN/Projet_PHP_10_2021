<?php

    class Connect {
        private $host = 'db';
        private $dbname = 'database';
        private $user = 'user';
        private $pass = 'pass';

        public function connexion() {
           $host = $this->host;
           $dbname = $this->dbname;
           $user = $this->user;
           $pass = $this->pass;
           $dsn = "mysql:host=$host;dbname=$dbname;charset=utf8";
           return $connexion = new PDO($dsn, $user, $pass);
        }
    }