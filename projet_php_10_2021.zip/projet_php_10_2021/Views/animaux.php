<?php
session_start();
require_once('../Controller/Animal.php');
require_once ('../Controller/Animals.php');

$animalsdata = new Animals();

$animalsdata->getLastAnimals();

$animals = [];
$i = 0;
foreach ($animalsdata->getLastAnimals() as $animal ) {

    $animalrow = new Animal();
    $animalrow->getAnimal($animal["id"]);

    $animalrow->id =  $animalrow->getID();
    $animalrow->name = $animalrow->getName();
    $animalrow->race = $animalrow->getRace();
    $animalrow->type_animal = $animalrow->getType();
    $animalrow->date_naissance =  $animalrow->getBirth();
    $animalrow->date_prise_en_charge =  $animalrow->getTakenIn();
    $animalrow->available =  $animalrow->isAvailable();
    $animalrow->reserved =  $animalrow->isReserved();

    $animals[$i] = $animalrow;
    $i++;
}
?>

<html lang="EN">
    <body>
        <div id="container">
            <div id="animals">
                <?php
                    foreach ($animals as $animalhtml){
                        ?>
                        <div id="Animal<?php echo $animalhtml->id ?>">
                            <h1> <?php echo $animalhtml->name ?> </h1>
                            <p> Un <?php echo $animalhtml->type_animal ?>,
                                de race <?php echo $animalhtml->race ?></p>,
                            et reçu le <?php echo $animalhtml->date_prise_en_charge ?>
                            <a href='animal.php?id="<?php echo $animalhtml->id ?>"'>En savoir plus</a>
                        </div>
                        <?php
                    }
                ?>
            </div>
        </div>
    </body>
</html>