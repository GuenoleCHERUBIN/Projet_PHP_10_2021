<?php
$animalId = $_GET["id"];

echo $animalId;

